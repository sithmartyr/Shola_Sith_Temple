TITLE: Shola Sith Temple
AUTHOR: Darth Apocalypse
Mail: Darthapoc@yahoo.com
official page: http://de.jkhub.org/members/darthapocalypse

---Credits---
Special thanks to Darth Martyr for teaching me how to map and help me with the obsticles I 
came across in the making of this map. Without him I would never have started mapping. 

Special Thanks to Loda for helping me with advanced mapping info.

Special thanks to Circa and Radiuks for creating and helping me with some textures.

Added in October 2022, - A-Mountain by Acrobat
ATAT Vehicle walker by jhc

--Extra--

Map started on February 16th. 

and thanks to all -[DE]- for testing my map as I was working with it and giving good recommendations!

Took a break within two months of starting and got distracted in life, came back to finish in October 2022!

--To Install--
Place Shola Sith Temple.pk3 inside of your LucasArts/Star Wars Jedi Knight Jedi Academy/GameData/Base folder.

--To Uninstall--

Remove Shola Sith Temple.pk3 from your Base Folder. 

Possible bugs: Some textures might be missing for Jedi Knight players that use Steam. 



*************************************************************************************************
 
 THIS MOD FILE IS NOT MADE, DISTRIBUTED, OR SUPPORTED
 BY LUCASARTS ENTERTAINMENT COMPANY LLC. ELEMENTS
 TM & LUCASARTS ENTERTAINMENT COMPANY LLC AND/OR
 ITS LICENSORS. 